A Pen created at CodePen.io. You can find this one at http://codepen.io/msaetre/pen/nlsJL.

 Move the sun around with your mouse